
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from scrapy.selector import Selector
import json
import sqlite3
import csv
import os

os.makedirs('data', exist_ok=True)
os.makedirs('db', exist_ok=True)

options = Options()
options.add_argument("--headless")
driver = webdriver.Chrome(options=options)

url = "https://csie.asia.edu.tw/zh_tw/associate_professors_2"
driver.get(url)
driver.implicitly_wait(5)
html = driver.page_source
driver.quit()

sel = Selector(text=html)
professors = sel.css('.teacher_info')

results = []
for prof in professors:
    name = prof.css('.teacher_name::text').get().strip()
    expertise = prof.css('.teacher_info_list li::text').getall()
    results.append({"name": name, "expertise": expertise})

with open('data/professors.json', 'w', encoding='utf-8') as f:
    json.dump(results, f, ensure_ascii=False, indent=4)

with open('data/professors.csv', 'w', newline='', encoding='utf-8') as f:
    writer = csv.writer(f)
    writer.writerow(['Name', 'Expertise'])
    for item in results:
        writer.writerow([item['name'], ', '.join(item['expertise']))

with open('data/professors.txt', 'w', encoding='utf-8') as f:
    for item in results:
        f.write(f"Name: {item['name']}\nExpertise: {', '.join(item['expertise'])}\n\n")

conn = sqlite3.connect('db/professors.db')
c = conn.cursor()
c.execute('CREATE TABLE IF NOT EXISTS professors (name TEXT, expertise TEXT)')
for item in results:
    c.execute("INSERT INTO professors (name, expertise) VALUES (?, ?)",
              (item['name'], ', '.join(item['expertise'])))
conn.commit()
conn.close()

print("✅ 資料已全部完成儲存！")
