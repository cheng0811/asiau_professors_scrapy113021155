
# 亞洲大學資工系副教授專長爬蟲專案

## 🕷 專案說明
本專案透過 Selenium + Scrapy 組合，從亞洲大學資工系網頁自動擷取副教授姓名與專長。

網址：[https://csie.asia.edu.tw/zh_tw/associate_professors_2](https://csie.asia.edu.tw/zh_tw/associate_professors_2)

---

## 💡 技術特色
- 使用 Selenium 模擬瀏覽器，載入完整網頁資料。
- 使用 Scrapy Selector 快速提取資料。
- 支援儲存 JSON / CSV / TXT / SQLite。

---

## 📦 執行方式
```bash
pip install -r requirements.txt
python hybrid_spider.py
```
執行後結果會輸出至 `data/` 與 `db/` 目錄。
